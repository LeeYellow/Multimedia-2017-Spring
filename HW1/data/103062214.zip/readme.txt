read me.txt

	(1) how to execute my matlab program?
		-> download and unzip the 103062214_hw1.zip
		-> open your matlab and  switch your current folder to 103062214_hw1
		-> choose the problem to demo
			1)for the problem 1, open the file: DCT image compression
			2)for the problem 2, open the file: Image filter 
			3)for the problem 3, open the file: Interpolation
		-> choose the subproblem to demo
			1)to demo (a) subproblem, text the command as follow: main_a
			1)to demo (b) subproblem, text the command as follow: main_b

	(2) attention:
		-> all my output image in the same subproblem will pop out at the same time in different windows.
		-> all my output psnr in the same subproblem will display in the command window at the same time.

	(3) output image:
		-> all the output images have been put in their own folder. ex: output_main_a_XXX.jpg